# AUD/JPY Live Signal — no Quotex SSID

This version removes the Quotex SSID/session-token requirement.

It uses Twelve Data's forex API for 1-minute history and its WebSocket price stream for live updates. Twelve Data documents 1-minute time series and WebSocket streaming, and requires an API key. citeturn1search1turn1search9

## iPhone
1. Host this folder on an HTTPS static host.
2. Open the HTTPS URL in Safari.
3. Enter your Twelve Data API key.
4. Tap Connect to live market.
5. Safari Share → Add to Home Screen.

The feed is external to Quotex, so it is not guaranteed to match Quotex's quote exactly.
