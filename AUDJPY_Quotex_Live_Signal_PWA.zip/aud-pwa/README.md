# AUD/JPY Live Signal — rebuilt runnable version

This is a browser-installable PWA. It reads live Quotex market data through the WebSocket protocol documented by an unofficial open-source implementation and calculates a simple 1-minute directional signal. It does NOT place trades.

## Run
1. Serve this folder from HTTPS or localhost (for example `python -m http.server 8080`).
2. Open the page in Chrome/Safari.
3. Enter your own Quotex session token locally. Never send the token to anyone.
4. Select AUDJPY and 1 minute, then Connect.
5. After enough live candles arrive, the panel shows UP, DOWN, or SKIP.

## Important
The WebSocket protocol is unofficial and may change. Quotex's own rules state its server is the authoritative quote source and prohibit automated mechanisms that execute operations. This app is intentionally signal-only.
