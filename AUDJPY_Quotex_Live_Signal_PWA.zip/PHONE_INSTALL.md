# AUD/JPY Live Signal — phone-only installation

## Fastest route
1. Upload this folder to any static HTTPS host (Render Static Site is one option).
2. Open the resulting `https://...` address in Chrome on Android.
3. Tap Chrome `⋮` → **Add to Home screen** (or **Install app** if shown).
4. Launch it from the Home screen.

## Important
This is a web/PWA package, not an APK. The live signal engine remains manual/signal-only.
The service worker caches the app shell but leaves external live-data requests on the network.

## Render
The included `render.yaml` is configured as a static site. Create a Render Static Site from this project and publish the folder containing `index.html`.
